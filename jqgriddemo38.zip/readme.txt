jqGrid Examples.

To make this work you must create database griddemo (or what you want).
Enter the appropiate information in dbconfig.php.
Execute the database.sql script in MySQL server.
Copy the files to web server and open jqgrid.html via web browser.

