<?php
$dbhost = 'localhost';
$dbuser   = 'root';
$dbpassword = '';
$database = 'griddemo';

?>
